function showPrivate() {  
    // Write your own code!
}

function openURL() {
    // Write your own code!
}

window.onload = function () {
    let unveil = document.getElementById('unveil');
    let contact = document.getElementById('contact');

    // Write your own code!
}
