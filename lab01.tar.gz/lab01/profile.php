<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="main.css">
  <script type="text/javascript" src="app.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
  <div class="container">
    <div class="left card">
        <!-- Write your own code! -->
        <h1>Your Name</h1>
        <p class="school">KAIST</p>
         <!-- Change with your own link! -->
        <a href="#" class="fa fa-google"></a>
        <a href="#" class="fa fa-facebook"></a>
        <a href="#" class="fa fa-twitter"></a>
        <a href="#" class="fa fa-youtube"></a>
        <p><button id="contact">Contact</button></p>
    </div>
    <div class="right card">
      <!-- Write your own code! --> 
      <div id="private" style="">
        <h2>Private Info</h1>
        <!-- Write your own code! -->
      </div>
      <p><button id="unveil">Unveil</button></p>
    </div>
  </div>
</body>
</html>




